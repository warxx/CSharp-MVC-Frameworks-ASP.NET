﻿namespace CarDealer.Models.ViewModels
{
    public class PartVm
    {
        public string Name { get; set; }
        public double? Price { get; set; }
    }
}
